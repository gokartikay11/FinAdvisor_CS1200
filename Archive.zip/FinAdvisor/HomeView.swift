//
//  HomeView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/10/25.
//
import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var auth: AuthViewModel

    var body: some View {
        ZStack {
            AppBackground()

            VStack(spacing: 20) {
                Image(systemName: "creditcard.and.123")
                    .font(.system(size: 48))
                    .foregroundStyle(AppTheme.brandBlack)

                Text("Welcome to FinAdvisor")
                    .font(.title2.bold())

                Text("You’re signed in. This is a placeholder home screen.")
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 24)

                Button {
                    auth.logout()
                } label: {
                    Text("Log Out")
                        .fontWeight(.semibold)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(.white)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(AppTheme.separator)
                        )
                        .cornerRadius(12)
                        .padding(.horizontal, 24)
                }
                .padding(.top, 8)

                Spacer()
            }
        }
    }
}
