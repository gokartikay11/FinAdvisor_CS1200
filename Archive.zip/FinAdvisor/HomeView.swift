//
//  HomeView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/10/25.
//

import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var auth: AuthViewModel

    var body: some View {
        NavigationStack {
            ZStack {
                // Background
                AppBackground()
                    .ignoresSafeArea()

                // Main content
                VStack(spacing: 22) {
                    // --- APP LOGO ---
                    Image("finadvisor_logo_1024")   // make sure this matches your asset name
                        .resizable()
                        .scaledToFit()
                        .frame(width: 120, height: 120)
                        .shadow(radius: 10)
                        .padding(.top, 40)

                    // --- TITLE ---
                    Text("Welcome to FinAdvisor")
                        .font(.title2.bold())
                        .foregroundStyle(.white)

                    // --- SUBTITLE ---
                    Text("You’re signed in. Track expenses, income and insights all in one place.")
                        .font(.body)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 28)

                    // --- MAIN LOG OUT BUTTON (optional, extra) ---
                    Button {
                        auth.logout()
                    } label: {
                        Text("Log Out")
                            .fontWeight(.semibold)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(.white)
                            .foregroundColor(.black)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(AppTheme.separator, lineWidth: 1)
                            )
                            .cornerRadius(12)
                            .padding(.horizontal, 24)
                    }
                    .padding(.top, 12)

                    Spacer()
                }
            }
            .navigationTitle("Home")
            .navigationBarTitleDisplayMode(.inline)

            // 🔹 TOP-RIGHT HELP + PROFILE BUTTONS
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    HStack(spacing: 16) {

                        // HELP → AI / help chat
                        NavigationLink {
                            ChatView()      // file already exists in your project
                        } label: {
                            Image(systemName: "questionmark.circle")
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundStyle(.white)
                        }

                        // PROFILE → screen with user details + logout
                        NavigationLink {
                            ProfileView()   // uses your existing ProfileView.swift
                        } label: {
                            Image(systemName: "person.crop.circle")
                                .font(.system(size: 22, weight: .semibold))
                                .foregroundStyle(.white)
                        }
                    }
                }
            }
        }
    }
}
