//
//  LoginView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/10/25.
//
import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

struct LoginView: View {
    @EnvironmentObject private var auth: AuthViewModel
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var error: String?
    @State private var showingSignup = false
    @State private var showingReset = false

    var body: some View {
        ZStack {
            AppBackground()

            VStack(spacing: 18) {
                Text("FinAdvisor")
                    .font(.system(size: 34, weight: .bold))
                    .padding(.top, 16)

                VStack(spacing: 6) {
                    Text("Welcome!").font(.headline)
                    Text("Create your account or Login if you already have one")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 24)
                }
                .padding(.top, 8)

                VStack(spacing: 12) {
                    TextField("email@domain.com", text: $email)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.emailAddress)
                        .autocorrectionDisabled(true)
                        .textContentType(.none)
                        .padding(.horizontal, 14)
                        .frame(height: AppTheme.buttonHeight)
                        .background(AppTheme.fieldBG)
                        .clipShape(RoundedRectangle(cornerRadius: AppTheme.corner))

                    SecureField("Enter your password", text: $password)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.asciiCapable)
                        .autocorrectionDisabled(true)
                        .textContentType(.none)
                        .privacySensitive()
                        .padding(.horizontal, 14)
                        .frame(height: AppTheme.buttonHeight)
                        .background(AppTheme.fieldBG)
                        .clipShape(RoundedRectangle(cornerRadius: AppTheme.corner))

                    if let error {
                        Text(error)
                            .foregroundStyle(.red)
                            .font(.footnote)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }

                    PrimaryButton(title: "Continue") { submitLogin() }
                        .disabled(!canSubmit)
                        .opacity(canSubmit ? 1 : 0.6)

                    Button("Forgot password?") { showingReset = true }
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .padding(.top, 2)
                }
                .padding(.horizontal, 20)

                HStack {
                    Rectangle().fill(AppTheme.separator).frame(height: 1)
                    Text("or").foregroundStyle(.secondary).font(.caption)
                    Rectangle().fill(AppTheme.separator).frame(height: 1)
                }
                .padding(.horizontal, 20)

                // GOOGLE + APPLE ROWS
                VStack(spacing: 12) {
                    GoogleButton()
                    OutlineBrandRow(systemIcon: "apple.logo", title: "Continue with Apple")
                }
                .padding(.horizontal, 20)

                HStack(spacing: 6) {
                    Text("Dont have an account?")
                    Button("Sign up here") { showingSignup = true }
                        .foregroundStyle(AppTheme.linkBlue)
                }
                .font(.subheadline)
                .padding(.top, 6)

                Spacer(minLength: 0)
                TermsFooter()
                    .padding(.horizontal, 24)
                    .padding(.bottom, 10)
            }
        }
        .sheet(isPresented: $showingSignup) {
            SignupView().environmentObject(auth)
        }
        .sheet(isPresented: $showingReset) {
            PasswordResetView().environmentObject(auth)
        }
        .transaction { $0.animation = nil }
    }

    private var canSubmit: Bool {
        AuthViewModel.isValidEmail(email) && !password.isEmpty
    }
    private func submitLogin() {
        error = nil
        do { try auth.login(email: email, password: password) }
        catch { errorMessage(error) }
    }
    private func errorMessage(_ e: Error) {
        self.error = (e as? LocalizedError)?.errorDescription ?? "Something went wrong."
    }
}

// Real Google logo (from Assets) fallback → SF Symbol if asset missing
struct GoogleButton: View {
    var action: () -> Void = {}

    var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                googleLogo
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 18, height: 18)
                Text("Continue with Google").fontWeight(.semibold)
                Spacer()
            }
            .padding(.vertical, 12)
            .padding(.horizontal, 14)
            .background(Color(uiColor: .systemBackground))
            .overlay(RoundedRectangle(cornerRadius: AppTheme.corner).stroke(AppTheme.separator))
            .clipShape(RoundedRectangle(cornerRadius: AppTheme.corner))
        }
        .buttonStyle(.plain)
    }

    private var googleLogo: Image {
        #if canImport(UIKit)
        if let ui = UIImage(named: "GoogleLogo") { return Image(uiImage: ui) }
        #endif
        return Image(systemName: "g.circle") // fallback if asset not added yet
    }
}
