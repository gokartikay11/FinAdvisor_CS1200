//
//  ChatView.swift
//  FinAdvisor
//

import SwiftUI

struct ChatView: View {

    // Chat history
    @State private var messages: [ChatMessage] = [
        ChatMessage(
            role: .assistant,
            text: "Hey! I'm your AI assistant. How can I help you today?"
        )
    ]

    @State private var draft: String = ""
    @State private var isSending: Bool = false

    // ⚠️ Put your real Gemini API key here
    private let service: ChatService = GeminiChatService(
        apiKey: "AIzaSyCLQhbHaPTAQBvx5P1ZQQRhxxoG-MNr9kQ"
        // model: "gemini-2.0-flash" // optional, default already that
    )

    var body: some View {
        VStack(spacing: 0) {

            // MARK: Header
            HStack {
                Text("AI ChatBox")
                    .font(.title3.bold())
                Spacer()
            }
            .padding()
            .background(.ultraThinMaterial)

            // MARK: Messages
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 12) {
                        ForEach(messages) { msg in
                            ChatBubble(message: msg)
                                .id(msg.id)
                        }
                    }
                    .padding(.horizontal, 10)
                    .padding(.top, 10)
                }
                // iOS 17–style onChange (no deprecation)
                .onChange(of: messages) { _, _ in
                    if let last = messages.last {
                        withAnimation {
                            proxy.scrollTo(last.id, anchor: .bottom)
                        }
                    }
                }
            }

            // MARK: Input bar
            HStack(spacing: 8) {
                TextField("Message…", text: $draft, axis: .vertical)
                    .textFieldStyle(.roundedBorder)
                    .lineLimit(1...4)

                Button {
                    Task { await send() }
                } label: {
                    Image(systemName: "paperplane.fill")
                        .padding(10)
                }
                .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isSending)
            }
            .padding()
            .background(.ultraThinMaterial)
        }
    }

    // MARK: - Send message

    private func send() async {
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }

        draft = ""
        isSending = true

        // Append user message
        let userMsg = ChatMessage(role: .user, text: text)
        messages.append(userMsg)

        do {
            // Ask Gemini (no streaming; single reply string)
            let replyText = try await service.sendMessage(text, history: messages)
            let replyMsg = ChatMessage(role: .assistant, text: replyText)
            messages.append(replyMsg)
        } catch {
            // Show error as assistant bubble
            let errorMsg = ChatMessage(
                role: .assistant,
                text: "⚠️ \(error.localizedDescription)",
                isError: true
            )
            messages.append(errorMsg)
        }

        isSending = false
    }
}

// MARK: - Chat bubble view

private struct ChatBubble: View {
    let message: ChatMessage

    private var isUser: Bool {
        message.role == .user
    }

    var body: some View {
        HStack {
            if isUser { Spacer() }

            Text(message.text)
                .padding(10)
                .foregroundStyle(isUser ? .white : .black)
                .background(isUser ? Color.black : Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(isUser ? .clear : Color.gray.opacity(0.2))
                )
                .frame(
                    maxWidth: UIScreen.main.bounds.width * 0.7,
                    alignment: .leading
                )

            if !isUser { Spacer() }
        }
        .padding(.horizontal, 4)
    }
}
