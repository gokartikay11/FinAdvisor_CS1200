//
//  SettingsView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/11/25.
//
import SwiftUI

// MARK: - Settings
struct SettingsView: View {
    @EnvironmentObject private var auth: AuthViewModel
    @EnvironmentObject private var finance: FinanceStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack {
                        Circle().frame(width: 44, height: 44)
                        VStack(alignment: .leading) {
                            Text("John Doe").font(.headline)
                            Text("john.doe@email.com")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text("View Profile").foregroundStyle(.secondary)
                    }
                }

                Section("General") {
                    Toggle("Notifications", isOn: .constant(true))
                    Toggle("Dark Mode", isOn: .constant(false))
                    HStack { Text("Language"); Spacer(); Text("English").foregroundStyle(.secondary) }
                }

                Section("Security & Privacy") {
                    Toggle("Biometric Login", isOn: .constant(true))
                    NavigationLink("Change Password") { PasswordResetView() }
                    NavigationLink("Privacy Settings") { PoliciesView() } // <-- exists below
                }

                Section {
                    Button("Sign Out", role: .destructive) { auth.logout() }
                }
            }
            .navigationTitle("Settings")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
        }
    }
}

// MARK: - Policies
struct PoliciesView: View {
    var body: some View {
        List {
            Section("Policy Updates") {
                HStack { Text("Privacy Policy Update"); Spacer(); Tag("NEW") }
                HStack { Text("New Security Features");  Spacer(); Tag("NEW") }
                Text("Terms of Service Changes")
                Text("Data Protection Guidelines")
            }
            Section("Support") {
                NavigationLink("Help Center") { SupportView() }
                Text("Terms of Service")
            }
        }
        .navigationTitle("Policies")
    }

    private func Tag(_ text: String) -> some View {
        Text(text)
            .font(.caption2).padding(.horizontal, 6).padding(.vertical, 2)
            .background(Color.uiBackground).clipShape(Capsule())
    }
}

// MARK: - Support
struct SupportView: View {
    var body: some View {
        List {
            Section("How can we help?") {
                Text("Tell us about the issue you’re having")
                Text("Get in touch with us")
            }
            Section("FAQ") {
                Text("Cannot login into account?")
                Text("Is my financial information secure?")
                Text("How can I link a new bank?")
            }
        }
        .navigationTitle("Support Center")
    }
}

// small helper so the tag background matches cards
private extension Color {
    static let uiBackground = Color(UIColor.systemBackground)
}
