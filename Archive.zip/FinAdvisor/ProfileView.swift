//
//  ProfileView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/11/25.
//
import SwiftUI

struct ProfileView: View {
    @EnvironmentObject private var auth: AuthViewModel

    var body: some View {
        ZStack {
            AppBackground()
            List {
                Section {
                    HStack(spacing: 12) {
                        Circle().frame(width: 56, height: 56)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(auth.profile?.name.isEmpty == false ? auth.profile!.name : "Your Name")
                                .font(.headline)
                            Text(auth.profile?.email ?? "email@domain.com")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }

                Section("Personal") {
                    row("Phone", auth.profile?.phone ?? "—")
                    row("Birthday", auth.profile?.birthday ?? "—")
                    row("Age", auth.profile?.age ?? "—")
                }

                Section("Security & Privacy") {
                    NavigationLink("Change Password") { PasswordResetView() }
                }

                Section {
                    Button("Sign Out", role: .destructive) { auth.logout() }
                }
            }
            .navigationTitle("Profile")
        }
    }

    private func row(_ title: String, _ value: String) -> some View {
        HStack { Text(title); Spacer(); Text(value).foregroundStyle(.secondary) }
    }
}
