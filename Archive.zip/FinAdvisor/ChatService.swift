import Foundation

// MARK: - Basic chat types

enum Sender: String, Codable {
    case user
    case assistant
}

struct ChatMessage: Identifiable, Codable, Equatable {
    let id: UUID
    let role: Sender
    let text: String
    let isError: Bool

    init(id: UUID = UUID(),
         role: Sender,
         text: String,
         isError: Bool = false) {

        self.id = id
        self.role = role
        self.text = text
        self.isError = isError
    }
}

// MARK: - ChatService protocol

protocol ChatService {
    func sendMessage(
        _ text: String,
        history: [ChatMessage]
    ) async throws -> String
}

// MARK: - Gemini implementation

final class GeminiChatService: ChatService {
    private let apiKey: String
    private let model: String

    init(apiKey: String,
         model: String = "gemini-2.0-flash") {
        self.apiKey = apiKey
        self.model = model
    }

    private struct GeminiRequest: Codable {
        struct Part: Codable { let text: String }
        struct Content: Codable {
            let role: String?
            let parts: [Part]
        }
        let contents: [Content]
    }

    private struct GeminiResponse: Codable {
        struct Candidate: Codable {
            struct Content: Codable {
                struct Part: Codable { let text: String? }
                let parts: [Part]
            }
            let content: Content
        }
        let candidates: [Candidate]?
        let error: GeminiError?
    }

    struct GeminiError: Codable, Error {
        let code: Int?
        let message: String?
        let status: String?
    }

    func sendMessage(
        _ text: String,
        history: [ChatMessage]
    ) async throws -> String {

        var contents: [GeminiRequest.Content] = []

        for msg in history {
            contents.append(
                .init(role: msg.role == .user ? "user" : "model",
                      parts: [.init(text: msg.text)])
            )
        }

        contents.append(
            .init(role: "user", parts: [.init(text: text)])
        )

        let body = GeminiRequest(contents: contents)

        guard var components = URLComponents(
            string:
        "https://generativelanguage.googleapis.com/v1beta/models/\(model):generateContent"
        ) else { throw URLError(.badURL) }

        components.queryItems = [
            URLQueryItem(name: "key", value: apiKey)
        ]

        guard let url = components.url else {
            throw URLError(.badURL)
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let http = response as? HTTPURLResponse else {
            throw URLError(.badServerResponse)
        }

        if http.statusCode != 200 {
            if let decoded = try? JSONDecoder().decode(GeminiResponse.self, from: data),
               let err = decoded.error {
                throw err
            }
            throw URLError(.badServerResponse)
        }

        let decoded = try JSONDecoder().decode(GeminiResponse.self, from: data)

        if let err = decoded.error { throw err }

        guard let candidate = decoded.candidates?.first else {
            throw URLError(.cannotParseResponse)
        }

        return candidate.content.parts.compactMap { $0.text }.joined()
    }
}

