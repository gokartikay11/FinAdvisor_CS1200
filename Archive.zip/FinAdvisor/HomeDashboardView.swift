//
//  HomeDashboardView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/11/25.
//
import SwiftUI
#if canImport(Charts)
import Charts
#endif

struct HomeDashboardView: View {
    @EnvironmentObject private var finance: FinanceStore
    @EnvironmentObject private var auth: AuthViewModel

    // Demo trend data (mini chart)
    struct TrendPoint: Identifiable {
        let id = UUID()
        let month: String
        let income: Double
        let spend: Double
    }
    private let trend: [TrendPoint] = [
        .init(month: "Feb", income: 4200, spend: 3100),
        .init(month: "Mar", income: 4000, spend: 3200),
        .init(month: "Apr", income: 4300, spend: 3400),
        .init(month: "May", income: 4400, spend: 3600),
        .init(month: "Jun", income: 4500, spend: 3900)
    ]

    var body: some View {
        ZStack {
            AppBackground()

            ScrollView {
                VStack(alignment: .leading, spacing: 16) {

                    // Top bar ---------------------------------------------------
                    HStack(spacing: 16) {
                        NavigationLink { SupportView() } label: {
                            Image(systemName: "line.3.horizontal")
                                .font(.system(size: 18, weight: .semibold))
                        }
                        Spacer()
                        Text("FinAdvisor").font(.title2.bold())
                        Spacer()
                        HStack(spacing: 16) {
                            NavigationLink { SettingsView() } label: {
                                Image(systemName: "gearshape")
                                    .font(.system(size: 18, weight: .semibold))
                            }
                            NavigationLink { ProfileView() } label: {
                                Image(systemName: "person.crop.circle")
                                    .font(.system(size: 20, weight: .semibold))
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 8)

                    // Summary cards row ----------------------------------------
                    HStack(spacing: 12) {
                        summaryCard(title: "Total Income", value: finance.totalIncome)
                        summaryCard(title: "Total Balance", value: finance.totalBalance)
                        summaryCard(title: "Total Spending", value: finance.totalSpend)
                    }
                    .padding(.horizontal, 12)

                    // Budget Status + streak -----------------------------------
                    HStack {
                        Text("Budget Status").font(.subheadline)
                        Spacer()
                        Text("↑ \(finance.savingStreakDays) d. streak")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.horizontal, 16)

                    // Tiny trend chart (fallback to a simple box if Charts isn't present)
                    #if canImport(Charts)
                    Chart {
                        ForEach(trend) { p in
                            LineMark(x: .value("Month", p.month), y: .value("Income", p.income))
                                .foregroundStyle(.green)
                            LineMark(x: .value("Month", p.month), y: .value("Spend", p.spend))
                                .foregroundStyle(.red)
                        }
                    }
                    .frame(height: 160)
                    .padding(.horizontal, 16)
                    .background(Color(uiColor: .systemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(AppTheme.separator))
                    #else
                    Rectangle()
                        .fill(Color(uiColor: .systemBackground))
                        .frame(height: 160)
                        .overlay(Text("Trend chart (Charts not available)").font(.caption))
                        .padding(.horizontal, 16)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(AppTheme.separator))
                    #endif

                    // Saving Streak card (opens Assistant)
                    NavigationLink {
                        AssistantView()
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Saving Streak").font(.headline)
                                Text("\(finance.savingStreakDays) Day Saving Streak!")
                                    .font(.title3.bold())
                            }
                            Spacer()
                            Image(systemName: "flame.fill").font(.largeTitle)
                        }
                        .padding()
                        .background(Color(uiColor: .systemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .overlay(RoundedRectangle(cornerRadius: 16).stroke(AppTheme.separator))
                        .padding(.horizontal, 16)
                    }

                    // More to Explore ------------------------------------------
                    Text("More to Explore!")
                        .font(.subheadline)
                        .padding(.horizontal, 16)

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            exploreCard(title: "Track Every Expense", icon: "list.bullet.rectangle.portrait")
                            NavigationLink { AssistantView() } label: {
                                exploreCard(title: "Talk to AI ChatBox", icon: "bubble.left.and.bubble.right.fill")
                            }
                            NavigationLink { SettingsView() } label: {
                                exploreCard(title: "Payment & Settings", icon: "gearshape.fill")
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.bottom, 8)
                    }
                }
            }
        }
        .navigationBarBackButtonHidden(true)
        .transaction { $0.animation = nil } // keep it snappy & lag-free
    }

    // MARK: - Components

    private func summaryCard(title: String, value: Double) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            Text(currency(value)).fontWeight(.semibold)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(Color(uiColor: .systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.separator))
    }

    private func exploreCard(title: String, icon: String) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
            Text(title).font(.subheadline)
        }
        .padding(12)
        .frame(width: 220, alignment: .leading)
        .background(Color(uiColor: .systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.separator))
    }

    private func currency(_ n: Double) -> String {
        let f = NumberFormatter()
        f.numberStyle = .currency
        f.maximumFractionDigits = 2
        return f.string(from: NSNumber(value: n)) ?? "$0"
    }
}
