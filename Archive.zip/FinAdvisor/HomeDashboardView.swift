import SwiftUI

struct HomeDashboardView: View {

    // If ProfileView / logout uses AuthViewModel, this will already
    // be provided from the root (you don’t have to use it here yet,
    // but it’s ready if needed)
    @EnvironmentObject private var auth: AuthViewModel

    // MARK: - Which sheet is open
    private enum ActiveSheet: Identifiable {
        case income
        case expense
        case analyze

        var id: String {
            switch self {
            case .income:  return "income"
            case .expense: return "expense"
            case .analyze: return "analyze"
            }
        }
    }

    @State private var activeSheet: ActiveSheet?

    // MARK: - Fake demo data (replace with your real models later)
    struct AccountSummary: Identifiable {
        let id = UUID()
        let name: String
        let balance: String
    }

    struct ActivityItem: Identifiable {
        let id = UUID()
        let title: String
        let subtitle: String
        let amount: String
        let isNegative: Bool
    }

    private let accounts: [AccountSummary] = [
        .init(name: "Checking",    balance: "$2,150.32"),
        .init(name: "Savings",     balance: "$5,420.00"),
        .init(name: "Investments", balance: "$8,930.10")
    ]

    private let activities: [ActivityItem] = [
        .init(title: "Groceries", subtitle: "Today • Food & Dining",
              amount: "-$42.18", isNegative: true),
        .init(title: "Paycheck", subtitle: "Yesterday • Income",
              amount: "+$1,250.00", isNegative: false),
        .init(title: "Spotify", subtitle: "Fri • Subscription",
              amount: "-$9.99", isNegative: true)
    ]

    var body: some View {
        NavigationStack {
            ZStack {
                Color(.systemBackground)
                    .ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 24) {

                        headerSection
                        balanceCard
                        accountsRow
                        quickActions
                        recentActivity
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 16)
                    .padding(.bottom, 32)
                }
            }
            .navigationTitle("")
            .navigationBarHidden(true)
        }
        // ONE sheet that switches based on which button you pressed
        .sheet(item: $activeSheet) { sheet in
            switch sheet {
            case .income:
                EarningView()          // your Add Income screen
            case .expense:
                SpendingView()         // your Add Expense screen
            case .analyze:
                MoneyFlowView()        // or whatever you want for Analyze
            }
        }
    }

    // MARK: - Header

    private var headerSection: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Welcome back,")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)

                Text("FinAdvisor")
                    .font(.title.bold())
            }

            Spacer()

            // 🔹 Profile button → navigates to ProfileView (logout lives there)
            NavigationLink {
                ProfileView()              // existing view in your project
            } label: {
                Circle()
                    .fill(Color.blue.opacity(0.15))
                    .frame(width: 38, height: 38)
                    .overlay(
                        Image(systemName: "person.fill")
                            .font(.system(size: 18))
                            .foregroundStyle(.blue)
                    )
            }
        }
    }

    // MARK: - Balance Card

    private var balanceCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Total balance")
                .font(.subheadline)
                .foregroundStyle(.secondary)

            Text("$16,500.42")
                .font(.system(size: 32, weight: .bold, design: .rounded))

            HStack(spacing: 12) {
                Image(systemName: "arrow.up.right.circle.fill")
                    .font(.system(size: 16))
                Text("+4.2% this month")
                    .font(.subheadline)
                Spacer()
            }
            .foregroundStyle(.green)

            Divider().opacity(0.3)

            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Income")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text("$3,200")
                        .font(.subheadline.bold())
                }

                Spacer()

                VStack(alignment: .leading, spacing: 4) {
                    Text("Expenses")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text("$1,150")
                        .font(.subheadline.bold())
                }

                Spacer()
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [Color.blue.opacity(0.16), Color.blue.opacity(0.05)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        )
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.blue.opacity(0.12), lineWidth: 1)
        )
    }

    // MARK: - Accounts row

    private var accountsRow: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Accounts")
                    .font(.headline)
                Spacer()
                Button("View all") {}
                    .font(.subheadline)
            }

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(accounts) { account in
                        VStack(alignment: .leading, spacing: 6) {
                            Text(account.name)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                            Text(account.balance)
                                .font(.headline)
                        }
                        .padding(14)
                        .frame(width: 150, alignment: .leading)
                        .background(
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(Color(.secondarySystemBackground))
                        )
                    }
                }
                .padding(.horizontal, -4)
            }
        }
    }

    // MARK: - Quick actions

    private var quickActions: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Quick actions")
                .font(.headline)

            HStack(spacing: 12) {
                quickActionButton(
                    icon: "plus.circle.fill",
                    title: "Add income",
                    tint: .green
                ) {
                    activeSheet = .income
                }

                quickActionButton(
                    icon: "minus.circle.fill",
                    title: "Add expense",
                    tint: .red
                ) {
                    activeSheet = .expense
                }

                quickActionButton(
                    icon: "chart.bar.fill",
                    title: "Analyze",
                    tint: .blue
                ) {
                    activeSheet = .analyze
                }
            }
        }
    }

    private func quickActionButton(
        icon: String,
        title: String,
        tint: Color,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            VStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.system(size: 20))
                Text(title)
                    .font(.caption)
                    .multilineTextAlignment(.center)
            }
            .foregroundStyle(tint)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(tint.opacity(0.12))
            )
        }
        .buttonStyle(.plain)
    }

    // MARK: - Recent Activity

    private var recentActivity: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Recent activity")
                    .font(.headline)
                Spacer()
            }

            VStack(spacing: 10) {
                ForEach(activities) { item in
                    HStack(spacing: 12) {
                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .fill(Color(.secondarySystemBackground))
                            .frame(width: 36, height: 36)
                            .overlay(
                                Image(systemName: item.isNegative ? "arrow.down" : "arrow.up")
                                    .font(.system(size: 14, weight: .semibold))
                            )

                        VStack(alignment: .leading, spacing: 2) {
                            Text(item.title)
                                .font(.subheadline.bold())
                            Text(item.subtitle)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }

                        Spacer()

                        Text(item.amount)
                            .font(.subheadline.bold())
                            .foregroundStyle(item.isNegative ? .red : .green)
                    }
                }
            }
            .padding(12)
            .background(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(Color(.secondarySystemBackground))
            )
        }
    }
}
