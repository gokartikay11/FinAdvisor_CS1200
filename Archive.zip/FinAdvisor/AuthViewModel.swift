//
//  AuthViewModel.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/10/25.
//
import Foundation
import Combine
import CryptoKit

@MainActor
final class AuthViewModel: ObservableObject {

    // MARK: - Persisted auth state
    @Published var isAuthenticated: Bool = UserDefaults.standard.bool(forKey: "isAuthenticated")

    // MARK: - User Profile
    struct Profile: Codable {
        var name: String
        var email: String
        var birthday: String   // MM/DD/YYYY
        var age: String
        var phone: String
    }

    @Published var profile: Profile? = {
        if let data = UserDefaults.standard.data(forKey: "FA_PROFILE"),
           let p = try? JSONDecoder().decode(Profile.self, from: data) {
            return p
        }
        return nil
    }()

    private func saveProfile(_ p: Profile?) {
        if let p {
            let data = try? JSONEncoder().encode(p)
            UserDefaults.standard.set(data, forKey: "FA_PROFILE")
        } else {
            UserDefaults.standard.removeObject(forKey: "FA_PROFILE")
        }
        profile = p
    }

    func updateProfile(name: String, email: String, birthday: String, age: String, phone: String) {
        saveProfile(.init(name: name, email: email, birthday: birthday, age: age, phone: phone))
    }

    // MARK: - Simple demo user store  [ email : passwordHash ]
    private let usersKey = "FA_USERS_V1"

    private func loadUsers() -> [String:String] {
        (UserDefaults.standard.dictionary(forKey: usersKey) as? [String:String]) ?? [:]
    }
    private func saveUsers(_ users: [String:String]) {
        UserDefaults.standard.set(users, forKey: usersKey)
    }
    private func hash(_ text: String) -> String {
        let d = Data(text.utf8)
        let h = SHA256.hash(data: d)
        return h.compactMap { String(format: "%02x", $0) }.joined()
    }

    // MARK: - Validators
    static func isValidEmail(_ s: String) -> Bool {
        let s = s.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return s.contains("@") && s.contains(".")
    }

    // MARK: - API
    func signup(email: String, password: String, confirm: String) throws {
        let e = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard Self.isValidEmail(e) else { throw AuthError.invalidEmail }
        guard !password.isEmpty, password.count >= 6 else { throw AuthError.weakPassword }
        guard password == confirm else { throw AuthError.passwordsDontMatch }

        var users = loadUsers()
        guard users[e] == nil else { throw AuthError.userExists }
        users[e] = hash(password)
        saveUsers(users)

        setAuthenticated(true)
    }

    func login(email: String, password: String) throws {
        let e = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard Self.isValidEmail(e) else { throw AuthError.invalidEmail }
        guard !password.isEmpty else { throw AuthError.emptyPassword }

        let users = loadUsers()
        guard let stored = users[e] else { throw AuthError.userNotFound }
        guard stored == hash(password) else { throw AuthError.wrongPassword }

        setAuthenticated(true)
    }

    func resetPassword(email: String, newPassword: String, confirm: String) throws {
        let e = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard Self.isValidEmail(e) else { throw AuthError.invalidEmail }
        guard newPassword.count >= 6 else { throw AuthError.weakPassword }
        guard newPassword == confirm else { throw AuthError.passwordsDontMatch }

        var users = loadUsers()
        guard users[e] != nil else { throw AuthError.userNotFound }
        users[e] = hash(newPassword)
        saveUsers(users)
    }

    func logout() {
        setAuthenticated(false)
        saveProfile(nil) // clear profile on logout
        UserDefaults.standard.set(false, forKey: "fa_onboarding_done")
    }

    private func setAuthenticated(_ value: Bool) {
        UserDefaults.standard.set(value, forKey: "isAuthenticated")
        isAuthenticated = value
    }

    enum AuthError: LocalizedError {
        case invalidEmail, emptyPassword, weakPassword, passwordsDontMatch
        case userExists, userNotFound, wrongPassword
        var errorDescription: String? {
            switch self {
            case .invalidEmail:       return "Please enter a valid email."
            case .emptyPassword:      return "Password cannot be empty."
            case .weakPassword:       return "Password must be at least 6 characters."
            case .passwordsDontMatch: return "Passwords do not match."
            case .userExists:         return "An account with this email already exists."
            case .userNotFound:       return "No user found with this email."
            case .wrongPassword:      return "Incorrect password."
            }
        }
    }
}
