//
//  MoneyFlowView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/10/25.
//
import SwiftUI

struct MoneyFlowView: View {
    @EnvironmentObject private var auth: AuthViewModel

    @State private var income: String = ""
    @State private var spend: String = ""
    @State private var saving: String = ""
    @State private var investing: String = ""
    @State private var goal: String = ""

    private var net: Double {
        (Double(income) ?? 0) - (Double(spend) ?? 0)
    }
    private var rate: Double {
        let inc = Double(income) ?? 0
        let sav = Double(saving) ?? 0
        return inc > 0 ? max(0, sav / inc) : 0
    }
    private var canContinue: Bool {
        !(income.isEmpty || spend.isEmpty)
    }

    var body: some View {
        ZStack {
            AppBackground()

            ScrollView {
                VStack(spacing: 18) {
                    Text("FinAdvisor")
                        .font(.system(size: 34, weight: .bold))
                        .padding(.top, 16)

                    Text("Tell Us About Your Money Flow!")
                        .font(.headline)
                        .padding(.top, 4)

                    VStack(spacing: 12) {
                        moneyField("How much money do you make per month?", text: $income)
                        moneyField("How much money do you spend each month?", text: $spend)
                        moneyField("How much do you save each month? (optional)", text: $saving)
                        TextField("Do you invest money anywhere? (optional)", text: $investing)
                            .modifier(FieldStyle())
                        TextField("Do you want to make a Savings Goal? (optional)", text: $goal)
                            .modifier(FieldStyle())
                    }
                    .padding(.horizontal, 20)

                    // LIVE SUMMARY
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Summary")
                            .font(.headline)
                        HStack {
                            Text("Net each month")
                            Spacer()
                            Text(currency(net))
                                .fontWeight(.semibold)
                        }
                        HStack {
                            Text("Savings rate")
                            Spacer()
                            Text(String(format: "%.0f%%", rate * 100))
                                .fontWeight(.semibold)
                        }
                        .foregroundStyle(.secondary)
                    }
                    .padding(16)
                    .background(Color(uiColor: .systemBackground))
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.separator))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .padding(.horizontal, 20)

                    PrimaryButton(title: "Let's Get Started!") {
                        // TODO: navigate to your real dashboard
                    }
                    .disabled(!canContinue)
                    .opacity(canContinue ? 1 : 0.6)
                    .padding(.horizontal, 20)

                    Button("Log Out") { auth.logout() }
                        .foregroundStyle(.secondary)
                        .padding(.bottom, 8)

                    TermsFooter()
                        .padding(.horizontal, 24)
                        .padding(.bottom, 10)
                }
            }
        }
        .navigationBarBackButtonHidden(true)
        .transaction { $0.animation = nil }
    }

    private func moneyField(_ placeholder: String, text: Binding<String>) -> some View {
        TextField(placeholder, text: text)
            .keyboardType(.numberPad)
            .modifier(FieldStyle())
            .onChange(of: text.wrappedValue) { new in
                let filtered = new.filter { "0123456789.".contains($0) }
                if filtered != new { text.wrappedValue = filtered }
            }
    }

    private func currency(_ n: Double) -> String {
        let f = NumberFormatter()
        f.numberStyle = .currency
        f.maximumFractionDigits = 2
        return f.string(from: NSNumber(value: n)) ?? "$0"
    }
}

private struct FieldStyle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(.horizontal, 14)
            .frame(height: AppTheme.buttonHeight)
            .background(AppTheme.fieldBG)
            .clipShape(RoundedRectangle(cornerRadius: AppTheme.corner))
    }
}
