//
//  EarningView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/11/25.
//
import SwiftUI

struct EarningView: View {
    @EnvironmentObject private var finance: FinanceStore
    @State private var showConnect = false

    var body: some View {
        ZStack {
            AppBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    HStack {
                        Image(systemName: "line.3.horizontal")
                        Spacer()
                        Text("FinAdvisor").font(.title2.bold())
                        Spacer()
                        Image(systemName: "person.crop.circle")
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 8)

                    HStack {
                        Text("Earning").font(.headline)
                        Spacer()
                        Button {
                            showConnect = true
                        } label: {
                            HStack {
                                Image(systemName: "link")
                                Text("Connect Account")
                            }
                            .padding(8)
                            .overlay(RoundedRectangle(cornerRadius: 10).stroke(AppTheme.separator))
                        }
                    }
                    .padding(.horizontal, 16)

                    // totals
                    HStack(spacing: 12) {
                        totalsCard(title: "Total Balance", value: finance.totalBalance)
                        totalsCard(title: "Active Accounts", value: Double(finance.accounts.filter{$0.active}.count))
                    }.padding(.horizontal, 12)

                    VStack(spacing: 12) {
                        ForEach(finance.accounts) { acc in
                            VStack(alignment: .leading, spacing: 8) {
                                HStack {
                                    Circle().frame(width: 26, height: 26)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(acc.name).font(.subheadline)
                                        Text("\(acc.type) • \(acc.last4)").font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Text(currency(acc.balance)).fontWeight(.semibold)
                                }
                                HStack(spacing: 8) {
                                    Button(acc.active ? "Deactivate" : "Activate") { finance.toggleActive(acc) }
                                        .padding(8).overlay(RoundedRectangle(cornerRadius: 10).stroke(AppTheme.separator))
                                    Button("Edit") { } // stub
                                        .padding(8).overlay(RoundedRectangle(cornerRadius: 10).stroke(AppTheme.separator))
                                    Button("Disconnect") { finance.disconnect(acc) }
                                        .padding(8).overlay(RoundedRectangle(cornerRadius: 10).stroke(AppTheme.separator))
                                }
                            }
                            .padding(12)
                            .background(Color(uiColor: .systemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.separator))
                        }
                    }
                    .padding(.horizontal, 16)

                    Spacer(minLength: 20)
                }
            }
        }
        .sheet(isPresented: $showConnect) {
            ConnectBankView()
        }
    }

    private func totalsCard(title: String, value: Double) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            if title == "Active Accounts" {
                Text("\(Int(value)) of \(finance.accounts.count)").fontWeight(.semibold)
            } else {
                Text(currency(value)).fontWeight(.semibold)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(Color(uiColor: .systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.separator))
    }

    private func currency(_ n: Double) -> String {
        let f = NumberFormatter(); f.numberStyle = .currency; f.maximumFractionDigits = 2
        return f.string(from: NSNumber(value: n)) ?? "$0"
    }
}

