//
//  SpendingView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/11/25.
//

import SwiftUI

struct SpendingView: View {
    @EnvironmentObject private var finance: FinanceStore

    var body: some View {
        ZStack {
            AppBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    HStack {
                        Image(systemName: "line.3.horizontal")
                        Spacer()
                        Text("FinAdvisor").font(.title2.bold())
                        Spacer()
                        Image(systemName: "person.crop.circle")
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 8)

                    Text("Spending").font(.headline).padding(.horizontal, 16)

                    // Top categories (from budgets)
                    VStack(spacing: 10) {
                        ForEach(finance.budgets.prefix(3)) { b in
                            HStack {
                                Circle().frame(width: 10, height: 10)
                                Text(b.name)
                                Spacer()
                                Text(String(format: "%.0f%%", (b.spent / max(1,b.limit)) * 100))
                                    .foregroundStyle(.secondary)
                            }
                            .padding(.vertical, 8)
                            .padding(.horizontal, 12)
                            .background(Color(uiColor: .systemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.separator))
                        }
                    }
                    .padding(.horizontal, 16)

                    Text("Recent Transactions").font(.headline).padding(.horizontal, 16)

                    VStack(spacing: 10) {
                        ForEach(finance.transactions.sorted{ $0.date > $1.date }) { t in
                            HStack {
                                Circle().frame(width: 34, height: 34)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(t.title).font(.subheadline)
                                    Text(t.category).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Text(currency(t.amount))
                                    .fontWeight(.semibold)
                                    .foregroundStyle(t.amount < 0 ? .red : .green)
                            }
                            .padding(.vertical, 8)
                            .padding(.horizontal, 12)
                            .background(Color(uiColor: .systemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.separator))
                        }
                    }
                    .padding(.horizontal, 16)

                    Spacer(minLength: 20)
                }
            }
        }
    }

    private func currency(_ n: Double) -> String {
        let f = NumberFormatter(); f.numberStyle = .currency; f.maximumFractionDigits = 2
        return f.string(from: NSNumber(value: n)) ?? "$0"
    }
}
