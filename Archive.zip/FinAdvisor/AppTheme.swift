//
//  AppTheme.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/10/25.
//

import SwiftUI

enum AppTheme {
    static let brandBlack = Color.black
    static let brand = brandBlack           // alias for older calls
    static let linkBlue = Color(uiColor: .systemBlue)
    static let fieldBG = Color(uiColor: .secondarySystemBackground)
    static let separator = Color.black.opacity(0.1)

    static let corner: CGFloat = 12
    static let buttonHeight: CGFloat = 44
}

struct AppBackground: View {
    var body: some View { Color.white.ignoresSafeArea() } // flat, no GPU-heavy blur
}

struct PrimaryButton: View {
    let title: String
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title)
                .fontWeight(.semibold)
                .frame(maxWidth: .infinity, minHeight: AppTheme.buttonHeight)
                .foregroundStyle(.white)
                .background(AppTheme.brandBlack)
                .clipShape(RoundedRectangle(cornerRadius: AppTheme.corner))
        }
        .buttonStyle(.plain) // cheaper rendering
    }
}

struct OutlineBrandRow: View {
    let systemIcon: String
    let title: String
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: systemIcon)
            Text(title).fontWeight(.semibold)
            Spacer()
        }
        .padding(.vertical, 12)
        .padding(.horizontal, 14)
        .background(Color(uiColor: .systemBackground))
        .overlay(
            RoundedRectangle(cornerRadius: AppTheme.corner)
                .stroke(AppTheme.separator, lineWidth: 1)
        )
        .clipShape(RoundedRectangle(cornerRadius: AppTheme.corner))
    }
}

struct TermsFooter: View {
    var body: some View {
        Text("By clicking continue, you agree to our **Terms of Service** and **Privacy Policy**.")
            .font(.footnote)
            .foregroundStyle(.secondary)
            .multilineTextAlignment(.center)
    }
}
