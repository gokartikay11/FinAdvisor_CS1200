//
//  PlannerView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/11/25.
//
import SwiftUI

struct PlannerView: View {
    @EnvironmentObject private var finance: FinanceStore

    var body: some View {
        ZStack {
            AppBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    topBar(title: "Planner")

                    ForEach(finance.budgets) { b in
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text(b.name).font(.subheadline)
                                Spacer()
                                Text("\(currency(b.spent)) / \(currency(b.limit))")
                                    .font(.footnote)
                                    .foregroundStyle(b.spent > b.limit ? .red : .secondary)
                            }
                            ProgressView(value: min(b.spent / max(1, b.limit), 1.0))
                                .progressViewStyle(.linear)
                                .tint(b.spent > b.limit ? .red : .black)
                        }
                        .padding(12)
                        .background(Color(uiColor: .systemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.separator))
                    }
                    .padding(.horizontal, 16)

                    Button {
                        // add category flow (stub)
                        finance.budgets.append(.init(name: "New Category", limit: 300, spent: 0))
                    } label: {
                        HStack {
                            Image(systemName: "plus.circle")
                            Text("Add New Category")
                            Spacer()
                        }
                        .padding()
                        .background(Color(uiColor: .systemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(AppTheme.separator))
                        .padding(.horizontal, 16)
                    }

                    Spacer(minLength: 20)
                }
            }
        }
    }

    private func topBar(title: String) -> some View {
        HStack {
            Image(systemName: "line.3.horizontal")
            Spacer()
            Text("FinAdvisor").font(.title2.bold())
            Spacer()
            Image(systemName: "person.crop.circle")
        }
        .padding(.horizontal, 16)
        .padding(.top, 8)
    }

    private func currency(_ n: Double) -> String {
        let f = NumberFormatter(); f.numberStyle = .currency; f.maximumFractionDigits = 2
        return f.string(from: NSNumber(value: n)) ?? "$0"
    }
}

