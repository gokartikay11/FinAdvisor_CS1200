//
//  Helpers.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/11/25.
//
import SwiftUI

struct ZOOMFree<Content: View>: View {
    var content: () -> Content
    init(@ViewBuilder _ content: @escaping () -> Content) { self.content = content }
    var body: some View {
        content()
            .transaction { $0.animation = nil }
    }
}

