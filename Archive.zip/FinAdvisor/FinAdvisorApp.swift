//
//  FinAdvisorApp.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/10/25.
//

import SwiftUI

@main
struct FinAdvisorApp: App {
    @StateObject private var auth = AuthViewModel()
    @StateObject private var finance = FinanceStore()
    @AppStorage("fa_onboarding_done") private var onboardingDone: Bool = false

    var body: some Scene {
        WindowGroup {
            Group {
                if auth.isAuthenticated {
                    if onboardingDone {
                        NavigationStack {
                            MainTabView()
                        }
                        .environmentObject(auth)
                        .environmentObject(finance)
                    } else {
                        NavigationStack {
                            OnboardingFlowView()   // step-by-step, now skips review
                        }
                        .environmentObject(auth)
                        .environmentObject(finance)
                    }
                } else {
                    NavigationStack {
                        LoginView()
                    }
                    .environmentObject(auth)
                    .environmentObject(finance)
                }
            }
        }
    }
}
