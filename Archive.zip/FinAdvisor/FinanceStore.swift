//
//  FinanceStore.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/11/25.
//

import Foundation
import Combine   // <-- needed for ObservableObject/@Published

// MARK: - Models
struct BankAccount: Identifiable, Hashable {
    let id = UUID()
    var name: String
    var type: String   // "Bank Account", "Credit Card", etc.
    var last4: String
    var balance: Double
    var active: Bool
}

struct Transaction: Identifiable {
    let id = UUID()
    let title: String
    let category: String
    let date: Date
    let amount: Double   // negative = spend, positive = income
}

struct CategoryBudget: Identifiable {
    let id = UUID()
    let name: String
    var limit: Double
    var spent: Double
}

// MARK: - Store
final class FinanceStore: ObservableObject {
    @Published var accounts: [BankAccount] = []
    @Published var transactions: [Transaction] = []
    @Published var budgets: [CategoryBudget] = []

    // persist streak without @AppStorage (works outside Views)
    private let streakKey = "fa_saving_streak_days"
    var savingStreakDays: Int {
        get { (UserDefaults.standard.object(forKey: streakKey) as? Int) ?? 7 }
        set { UserDefaults.standard.set(newValue, forKey: streakKey) }
    }

    init() { seed() }

    // MARK: Seeds
    func seed() {
        accounts = [
            BankAccount(name: "Chase Checking", type: "Bank Account", last4: "4521", balance: 3120.50, active: true),
            BankAccount(name: "PayPal",         type: "Digital Wallet", last4: "8832", balance: 3250.50, active: true),
            BankAccount(name: "Visa Rewards",   type: "Credit Card",    last4: "1109", balance: 5500.00, active: true),
            BankAccount(name: "Savings Account",type: "Bank Account",   last4: "7734", balance: 8900.00, active: false)
        ]

        budgets = [
            CategoryBudget(name: "Housing",       limit: 1500, spent: 1150),
            CategoryBudget(name: "Food & Dining", limit: 520,  spent: 380),
            CategoryBudget(name: "Transportation",limit: 320,  spent: 260),
            CategoryBudget(name: "Entertainment", limit: 210,  spent: 120),
            CategoryBudget(name: "Utilities",     limit: 250,  spent: 220),
            CategoryBudget(name: "Shopping",      limit: 400,  spent: 460)
        ]

        let days = [0, 1, 3, 6, 9, 12, 20]
        transactions = [
            Transaction(title: "Salary",             category: "Earnings",        date: Date().addingTimeInterval(-Double(86400*days[6])), amount: +3500),
            Transaction(title: "Dinner at restaurant",category: "Food & Dining",  date: Date().addingTimeInterval(-Double(86400*1)),      amount: -42.75),
            Transaction(title: "Uber ride",          category: "Transportation",  date: Date().addingTimeInterval(-Double(86400*2)),      amount: -18.40),
            Transaction(title: "New jacket",         category: "Shopping",        date: Date().addingTimeInterval(-Double(86400*3)),      amount: -89.99)
        ]
    }

    // MARK: Computed
    var totalIncome: Double { transactions.filter { $0.amount > 0 }.map(\.amount).reduce(0,+) }
    var totalSpend:  Double { -transactions.filter { $0.amount < 0 }.map(\.amount).reduce(0,+) }
    var totalBalance: Double { accounts.filter { $0.active }.map(\.balance).reduce(0,+) }

    // MARK: Bank connect (mock)
    func connectInstitution(name: String, type: String, last4: String, balance: Double) {
        accounts.append(BankAccount(name: name, type: type, last4: last4, balance: balance, active: true))
    }
    func toggleActive(_ account: BankAccount) {
        if let i = accounts.firstIndex(of: account) { accounts[i].active.toggle() }
    }
    func disconnect(_ account: BankAccount) {
        accounts.removeAll { $0.id == account.id }
    }
}
