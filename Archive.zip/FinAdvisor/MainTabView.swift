//
//  MainTabView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/11/25.
//

import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            HomeDashboardView()
                .tabItem { Label("Home", systemImage: "house.fill") }

            PlannerView()
                .tabItem { Label("Planner", systemImage: "checklist") }

            SpendingView()
                .tabItem { Label("Spending", systemImage: "creditcard") }

            EarningView()
                .tabItem { Label("Earning", systemImage: "banknote") }

            ChatView()   // Chat tab = real chat
                .tabItem { Label("Chat", systemImage: "ellipsis.bubble.fill") }
        }
    }
}
