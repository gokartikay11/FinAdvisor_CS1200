//
//  SignupView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/10/25.
//
import SwiftUI

struct SignupView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var auth: AuthViewModel

    // Onboarding (visual) fields
    @State private var name: String = ""
    @State private var birthday: String = ""  // MM/DD/YYYY
    @State private var age: String = ""
    @State private var phone: String = ""     // auto formatted

    // Account fields
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var confirm: String = ""

    // UI state
    @State private var showPassword: Bool = false
    @State private var showConfirm: Bool = false
    @State private var error: String?

    var body: some View {
        ZStack {
            AppBackground()

            VStack(spacing: 18) {
                Text("FinAdvisor").font(.system(size: 34, weight: .bold)).padding(.top, 16)

                VStack(spacing: 6) {
                    Text("Hello Again!").font(.headline)
                    Text("Lets get to know you").font(.subheadline).foregroundStyle(.secondary)
                }.padding(.top, 8)

                // Profile info
                VStack(spacing: 12) {
                    TextField("Your Name", text: $name).modifier(FieldStyle())

                    TextField("Birthday (MM/DD/YYYY)", text: $birthday)
                        .keyboardType(.numbersAndPunctuation)
                        .modifier(FieldStyle())
                        .onChange(of: birthday) { _ in computeAge() }

                    TextField("Your Age", text: $age)
                        .disabled(true).foregroundStyle(.secondary)
                        .modifier(FieldStyle())

                    TextField("Phone Number", text: $phone)
                        .keyboardType(.numberPad)
                        .modifier(FieldStyle())
                        .onChange(of: phone) { new in
                            let f = formatUSPhone(new); if f != new { phone = f }
                        }
                }.padding(.horizontal, 20)

                // Account
                VStack(spacing: 12) {
                    TextField("email@domain.com", text: $email)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.emailAddress)
                        .autocorrectionDisabled(true)
                        .textContentType(.emailAddress)
                        .modifier(FieldStyle())

                    HStack {
                        Group {
                            if showPassword {
                                TextField("Create a password (min 6)", text: $password)
                                    .textInputAutocapitalization(.never)
                                    .keyboardType(.asciiCapable)
                                    .autocorrectionDisabled(true)
                                    .textContentType(.password)
                            } else {
                                SecureField("Create a password (min 6)", text: $password)
                                    .textInputAutocapitalization(.never)
                                    .keyboardType(.asciiCapable)
                                    .autocorrectionDisabled(true)
                                    .textContentType(.password)
                                    .privacySensitive()
                            }
                        }
                        Button { showPassword.toggle() } label: {
                            Image(systemName: showPassword ? "eye.slash" : "eye")
                                .font(.system(size: 17, weight: .medium))
                                .foregroundStyle(.secondary)
                        }
                    }
                    .modifier(FieldStyle())

                    HStack {
                        Group {
                            if showConfirm {
                                TextField("Confirm password", text: $confirm)
                                    .textInputAutocapitalization(.never)
                                    .keyboardType(.asciiCapable)
                                    .autocorrectionDisabled(true)
                                    .textContentType(.password)
                            } else {
                                SecureField("Confirm password", text: $confirm)
                                    .textInputAutocapitalization(.never)
                                    .keyboardType(.asciiCapable)
                                    .autocorrectionDisabled(true)
                                    .textContentType(.password)
                                    .privacySensitive()
                            }
                        }
                        Button { showConfirm.toggle() } label: {
                            Image(systemName: showConfirm ? "eye.slash" : "eye")
                                .font(.system(size: 17, weight: .medium))
                                .foregroundStyle(.secondary)
                        }
                    }
                    .modifier(FieldStyle())

                    if let error {
                        Text(error)
                            .foregroundStyle(.red)
                            .font(.footnote)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }

                    PrimaryButton(title: "Continue") { submit() }
                        .disabled(!canSubmit)
                        .opacity(canSubmit ? 1 : 0.6)
                }
                .padding(.horizontal, 20)

                Spacer(minLength: 0)
                TermsFooter().padding(.horizontal, 24).padding(.bottom, 10)
            }
        }
        .transaction { $0.animation = nil }
    }

    private var canSubmit: Bool {
        AuthViewModel.isValidEmail(email) && password.count >= 6 && !confirm.isEmpty
    }

    private func submit() {
        error = nil
        do {
            try auth.signup(email: email, password: password, confirm: confirm)
            // NEW: save profile so the Profile tab shows real data
            auth.updateProfile(name: name, email: email, birthday: birthday, age: age, phone: phone)
            dismiss()
        } catch {
            self.error = (error as? LocalizedError)?.errorDescription ?? "Something went wrong."
        }
    }

    // Age from MM/DD/YYYY
    private func computeAge() {
        let parts = birthday.split(separator: "/").map(String.init)
        guard parts.count == 3,
              let m = Int(parts[0]), let d = Int(parts[1]), let y = Int(parts[2]),
              (1...12).contains(m), (1...31).contains(d), (1900...3000).contains(y) else { age = ""; return }
        var comps = DateComponents(); comps.year = y; comps.month = m; comps.day = d
        if let dob = Calendar.current.date(from: comps) {
            let years = Calendar.current.dateComponents([.year], from: dob, to: Date()).year ?? 0
            age = String(max(0, years))
        } else { age = "" }
    }

    // (xxx)-xxx-xxxx
    private func formatUSPhone(_ raw: String) -> String {
        let digits = raw.filter(\.isNumber).prefix(10)
        let a = Array(digits)
        switch a.count {
        case 0: return ""
        case 1...3: return "(" + String(a)
        case 4...6: return "(\(String(a[0...2])))-" + String(a[3...a.count-1])
        default:
            let first = String(a[0...2]), mid = String(a[3...5]), last = String(a[6...a.count-1])
            return "(\(first))-\(mid)-\(last)"
        }
    }
}

private struct FieldStyle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(.horizontal, 14)
            .frame(height: AppTheme.buttonHeight)
            .background(AppTheme.fieldBG)
            .clipShape(RoundedRectangle(cornerRadius: AppTheme.corner))
    }
}
