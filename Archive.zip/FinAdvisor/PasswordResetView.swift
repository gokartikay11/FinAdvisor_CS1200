//
//  PasswordResetView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/11/25.
//
import SwiftUI

struct PasswordResetView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var auth: AuthViewModel

    @State private var email: String = ""
    @State private var newPassword: String = ""
    @State private var confirm: String = ""
    @State private var message: String?

    var body: some View {
        ZStack {
            AppBackground()

            VStack(spacing: 18) {
                Text("Reset Password")
                    .font(.title2.bold())
                    .padding(.top, 20)

                // Input fields
                VStack(spacing: 12) {
                    TextField("email@domain.com", text: $email)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.emailAddress)
                        .autocorrectionDisabled(true)
                        .textContentType(.none) // no autofill sheet
                        .modifier(FieldStyle())

                    SecureField("New password (min 6)", text: $newPassword)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.asciiCapable)
                        .autocorrectionDisabled(true)
                        .textContentType(.none)   // prevent strong-password prompt
                        .privacySensitive()
                        .modifier(FieldStyle())

                    SecureField("Confirm new password", text: $confirm)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.asciiCapable)
                        .autocorrectionDisabled(true)
                        .textContentType(.none)
                        .privacySensitive()
                        .modifier(FieldStyle())
                }
                .padding(.horizontal, 20)

                if let message = message {
                    Text(message)
                        .font(.footnote)
                        // green for success, red otherwise
                        .foregroundStyle(message.hasPrefix("Success") ? .green : .red)
                        .multilineTextAlignment(.center)
                        .padding (.horizontal, 20)
                }

                PrimaryButton(title: "Update Password") { update() }
                    .disabled(!canSubmit)
                    .opacity(canSubmit ? 1 : 0.6)
                    .padding(.horizontal, 20)

                Button("Close") { dismiss() }
                    .foregroundStyle(.secondary)
                    .padding(.top, 6)

                Spacer()
                TermsFooter()
                    .padding(.horizontal, 24)
                    .padding(.bottom, 10)
            }
        }
        .transaction { $0.animation = nil }
    }

    private var canSubmit: Bool {
        AuthViewModel.isValidEmail(email) && newPassword.count >= 6 && !confirm.isEmpty
    }

    private func update() {
        do {
            try auth.resetPassword(email: email, newPassword: newPassword, confirm: confirm)
            message = "Success! Your password has been updated."
        } catch {
            message = (error as? LocalizedError)?.errorDescription ?? "Something went wrong."
        }
    }
}

// Shared field style for rounded text fields
private struct FieldStyle: ViewModifier {
    func applyPadding(to view: some View) -> some View { view } // no-op helper
    func body(content: Content) -> some View {
        content
            .padding(.horizontal, 14)
            .frame(height: AppTheme.buttonHeight)
            .background(AppTheme.fieldBG)
            .clipShape(RoundedRectangle(cornerRadius: AppTheme.corner))
    }
}
