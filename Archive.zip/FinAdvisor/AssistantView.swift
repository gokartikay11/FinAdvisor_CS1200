//
//  AssistantView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/11/25.
//
import SwiftUI

struct AssistantView: View {
    var body: some View {
        ChatView()   // Use the real chat, not demo
    }
}
