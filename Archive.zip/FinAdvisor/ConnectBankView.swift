//
//  ConnectBankView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/11/25.
//
import SwiftUI

struct ConnectBankView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var finance: FinanceStore

    struct Institution: Identifiable { let id = UUID(); let name: String; let type: String }
    private let institutions: [Institution] = [
        .init(name: "Chase", type: "Bank Account"),
        .init(name: "Bank of America", type: "Bank Account"),
        .init(name: "Wells Fargo", type: "Bank Account"),
        .init(name: "Robinhood", type: "Brokerage"),
        .init(name: "Cash App", type: "Digital Wallet")
    ]

    var body: some View {
        NavigationStack {
            List {
                Section("Choose Institution") {
                    ForEach(institutions) { inst in
                        Button {
                            let last4 = String(Int.random(in: 1000...9999))
                            let bal = Double(Int.random(in: 500...9000))
                            finance.connectInstitution(name: inst.name, type: inst.type, last4: last4, balance: bal)
                            dismiss()
                        } label: {
                            HStack {
                                Circle().frame(width: 26, height: 26)
                                Text("\(inst.name) • \(inst.type)")
                            }
                        }
                    }
                }
            }
            .navigationTitle("Connect Account")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
        }
    }
}

