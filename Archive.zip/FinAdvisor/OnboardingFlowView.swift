//
//  OnboardingFlowView.swift
//  FinAdvisor
//
//  Created by Kartikay Goyal on 11/11/25.
//

import SwiftUI

struct OnboardingFlowView: View {
    @EnvironmentObject private var auth: AuthViewModel
    @AppStorage("fa_onboarding_done") private var onboardingDone: Bool = false

    enum Step: Int, CaseIterable { case income, spend, investAsk, investAmount, saveAsk, saveAmount }
    @State private var step: Step = .income

    @State private var income: String = ""
    @State private var spend: String = ""
    @State private var investChoice: String = ""     // "Yes"/"No"
    @State private var investAmount: String = ""
    @State private var saveChoice: String = ""
    @State private var saveAmount: String = ""

    private var canNext: Bool {
        switch step {
        case .income:      return !income.isEmpty
        case .spend:       return !spend.isEmpty
        case .investAsk:   return !investChoice.isEmpty
        case .investAmount:return !investAmount.isEmpty
        case .saveAsk:     return !saveChoice.isEmpty
        case .saveAmount:  return !saveAmount.isEmpty
        }
    }

    var body: some View {
        ZStack {
            AppBackground()
            VStack(spacing: 18) {
                Text("FinAdvisor")
                    .font(.system(size: 34, weight: .bold))
                    .padding(.top, 16)

                Text(titleFor(step)).font(.headline).padding(.top, 4)

                Group {
                    switch step {
                    case .income:       amountField("How much money do you make per month?", text: $income)
                    case .spend:        amountField("How much money do you spend each month?", text: $spend)
                    case .investAsk:    yesNoPicker("Do you invest money anywhere?", selection: $investChoice)
                    case .investAmount: amountField("How much do you invest per month?", text: $investAmount)
                    case .saveAsk:      yesNoPicker("Do you want to make a Savings Goal?", selection: $saveChoice)
                    case .saveAmount:   amountField("What’s your monthly savings goal?", text: $saveAmount)
                    }
                }
                .padding(.horizontal, 20)

                Spacer(minLength: 0)

                HStack(spacing: 12) {
                    if step != .income {
                        Button("Back", action: goBack)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .overlay(RoundedRectangle(cornerRadius: AppTheme.corner).stroke(AppTheme.separator))
                            .buttonStyle(.plain)
                    }

                    PrimaryButton(title: stepIsFinal ? "Let's Get Started!" : "Next") {
                        if stepIsFinal {
                            onboardingDone = true
                        } else {
                            goNext()
                        }
                    }
                    .disabled(!canNext)
                    .opacity(canNext ? 1 : 0.6)
                }
                .padding(.horizontal, 20)

                TermsFooter()
                    .padding(.horizontal, 24)
                    .padding(.bottom, 10)
            }
        }
        .navigationBarBackButtonHidden(true)
        .transaction { $0.animation = nil }
        .onChange(of: investChoice) { if step == .investAsk, $0 == "No" { step = .saveAsk } }
        .onChange(of: saveChoice)   { if step == .saveAsk,   $0 == "No" { onboardingDone = true } }
    }

    private var stepIsFinal: Bool { step == .saveAmount }

    private func goNext() {
        switch step {
        case .income: step = .spend
        case .spend:  step = .investAsk
        case .investAsk: step = (investChoice == "Yes") ? .investAmount : .saveAsk
        case .investAmount: step = .saveAsk
        case .saveAsk: step = (saveChoice == "Yes") ? .saveAmount : step // if "No", onChange will finish
        case .saveAmount: break
        }
    }
    private func goBack() {
        switch step {
        case .income: break
        case .spend: step = .income
        case .investAsk: step = .spend
        case .investAmount: step = .investAsk
        case .saveAsk: step = (investChoice == "Yes") ? .investAmount : .investAsk
        case .saveAmount: step = .saveAsk
        }
    }

    private func amountField(_ placeholder: String, text: Binding<String>) -> some View {
        TextField(placeholder, text: text)
            .keyboardType(.decimalPad)
            .modifier(FieldStyle())
            .onChange(of: text.wrappedValue) { new in
                var out = ""; var seenDot = false
                for ch in new {
                    if ch.isNumber { out.append(ch) }
                    else if ch == ".", !seenDot { out.append("."); seenDot = true }
                }
                if out != new { text.wrappedValue = out }
            }
    }
    private func yesNoPicker(_ title: String, selection: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.subheadline)
            Picker(title, selection: selection) {
                Text("Select").tag("")
                Text("Yes").tag("Yes")
                Text("No").tag("No")
            }
            .pickerStyle(.menu)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 14)
            .frame(height: AppTheme.buttonHeight)
            .background(AppTheme.fieldBG)
            .clipShape(RoundedRectangle(cornerRadius: AppTheme.corner))
        }
    }
}

private func titleFor(_ step: OnboardingFlowView.Step) -> String {
    switch step {
    case .income: return "How much money do you make per month?"
    case .spend: return "How much money do you spend each month?"
    case .investAsk: return "Do you invest money anywhere?"
    case .investAmount: return "How much do you invest per month?"
    case .saveAsk: return "Do you want to make a Savings Goal?"
    case .saveAmount: return "What’s your monthly savings goal?"
    }
}

// Field style reused
private struct FieldStyle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(.horizontal, 14)
            .frame(height: AppTheme.buttonHeight)
            .background(AppTheme.fieldBG)
            .clipShape(RoundedRectangle(cornerRadius: AppTheme.corner))
    }
}
